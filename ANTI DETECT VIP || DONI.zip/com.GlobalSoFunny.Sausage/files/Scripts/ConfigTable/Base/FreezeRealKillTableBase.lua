



return FreezeRealKillTableBase