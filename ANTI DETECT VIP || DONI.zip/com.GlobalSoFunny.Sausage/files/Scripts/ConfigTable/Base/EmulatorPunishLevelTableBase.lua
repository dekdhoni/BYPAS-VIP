



return EmulatorPunishLevelTableBase