



return FreezeSuspiciousPunishTableBase