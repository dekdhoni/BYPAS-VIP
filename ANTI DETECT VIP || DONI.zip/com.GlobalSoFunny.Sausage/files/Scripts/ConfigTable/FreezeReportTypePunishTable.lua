local FreezeReportTypePunishTable = class({}, Assets.req("Scripts.ConfigTable.Base.FreezeReportTypePunishTableBase"))

--------------------------------------------自动生成--------------------------------------------

return FreezeReportTypePunishTable
