local FreezeSuspiciousPunishTable = class({}, Assets.req("Scripts.ConfigTable.Base.FreezeSuspiciousPunishTableBase"))

--------------------------------------------自动生成--------------------------------------------

return FreezeSuspiciousPunishTable
